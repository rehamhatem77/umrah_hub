<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;

class Offer extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'offer_code',
        'title',

        'desc',
        'rating',
        'number_of_rating_customers',
        'price_contain',
        'price_not_contain',
        
        'slug',
        'trip_type_id',
        'company_id',
        'duration_days',
        'price',
        'airline',
        'program',

        'tour_level',
        'is_special_offer',
        'is_featured',
        'is_popular',
        'is_active',
        'start_date',
        'end_date',
        'available_places',
        'whatsapp_number',
        'seo_title',
        'seo_description',
    ];

    protected $casts = [
        'is_special_offer' => 'boolean',
        'is_featured'      => 'boolean',
        'is_popular'       => 'boolean',
        'is_active'        => 'boolean',
        'start_date'       => 'date',
        'end_date'         => 'date',
        'program' => 'array', 
    ];

    /* ================= Relations ================= */

    // public function governorate()
    // {
    //     return $this->belongsTo(Governorate::class);
    // }
    public function governorates()
    {
        return $this->belongsToMany(Governorate::class);
    }

    public function tripType()
    {
        return $this->belongsTo(TripType::class);
    }

    public function company()
    {
        return $this->belongsTo(TourCompany::class);
    }

    public function images()
    {
        return $this->hasMany(OfferImage::class);
    }

    public function features()
    {
        return $this->belongsToMany(Feature::class);
    }
    //     public function hotel()
    // {
    //     return $this->belongsTo(Hotel::class);
    // }

    public function hotels()
    {
        return $this->belongsToMany(Hotel::class);
    }


    public function mainImage()
    {
        return $this->hasOne(OfferImage::class)
            ->where('is_main', true)
            ->whereNull('deleted_at');
    }


    /* ================= Query Scopes ================= */

    public function scopeActive(Builder $query)
    {
        return $query->where('is_active', true);
    }

    public function scopeAvailable(Builder $query)
    {
        return $query->where('available_places', '>', 0)
            ->whereDate('start_date', '>=', now());
    }

    public function scopeSpecial(Builder $query)
    {
        return $query->where('is_special_offer', true);
    }


    public function scopePopular($query)
    {
        return $query->where('is_popular', true);
    }

    public function scopeCheapest($query)
    {
        return $query->orderBy('price', 'asc');
    }

    public function scopeNearest($query)
    {
        return $query->orderBy('start_date', 'asc');
    }

    public function scopeRamadan($query)
    {
        return $query->where('title', 'like', '%رمضان%');
    }

    /* ================= Accessors ================= */

    public function getTourLevelLabelAttribute()
    {
        return match ($this->tour_level) {
            'economical' => 'اقتصادي',
            'standard'   => 'متوسط',
            'luxury'     => 'فاخر',
            'vip'        => 'VIP',
            default      => '',
        };
    }

    public function getAverageHotelRatingAttribute(): float
    {
        if (!$this->relationLoaded('hotels')) {
            return 0;
        }

        return round(
            $this->hotels->avg('stars') ?? 0,
            1
        );
    }

    public function getMainImageUrlAttribute(): string
    {
        if ($this->relationLoaded('mainImage') && $this->mainImage) {
            return Storage::url($this->mainImage->image_path);
        }

        if ($this->relationLoaded('images') && $this->images->first()) {
            return Storage::url($this->images->first()->image_path);
        }

        return '/images/placeholder.jpg';
    }

    public function getLocationsAttribute(): array
    {
        if (!$this->relationLoaded('hotels')) {
            return [];
        }

        return $this->hotels
            ->pluck('city')
            ->unique()
            ->values()
            ->toArray();
    }
}
