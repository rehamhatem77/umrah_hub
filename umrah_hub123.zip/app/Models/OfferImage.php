<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class OfferImage extends Model
{
     use SoftDeletes;
    protected $fillable = [
        'offer_id',
        'image_path',
        'is_main',
        'sort_order',
    ];

    public function offer()
    {
        return $this->belongsTo(Offer::class);
    }
}
