<?php

namespace App\Providers;

use App\Models\AdminContactPage;
use App\Models\Offer;
use App\Observers\OfferObserver;
use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Vite;
use Illuminate\Support\ServiceProvider;
use Inertia\Inertia;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Offer::observe(OfferObserver::class);


      Inertia::share([
        'auth' => fn () => [
            'user' => Auth::user(),
        ],
        'flash' => fn () => [
        'success' => session('success'),
        'error' => session('error'),
    ],
    'footer' => fn () => AdminContactPage::first(),
    ]);
        Vite::prefetch(concurrency: 3);
    }
}
