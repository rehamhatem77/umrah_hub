import ApplicationLogo from '@/Components/ApplicationLogo';
import Header from '@/Components/Header';
import { Link, usePage } from '@inertiajs/react';
import { useState, useEffect } from 'react';
import { 
    FiGrid, FiGift, FiStar, FiTrendingUp, FiMenu, FiLogOut,
    FiSettings,
    FiUsers,
    FiGlobe,
    FiHome,
    FiBriefcase
} from "react-icons/fi";
import { MdOutlineHotel, MdOutlineCategory } from "react-icons/md";
import { FaRegBuilding, FaMapLocationDot } from "react-icons/fa6";
import { FaHandsHelping, FaRegCommentDots } from "react-icons/fa";
import { LuPackagePlus } from "react-icons/lu";


import { BsStars } from "react-icons/bs";
import SidebarContent from '@/Components/Sidebar';
import FlashToast from '@/Components/FlashToast';

export default function AuthenticatedLayout({ children }) {
    const user = usePage().props.auth.user;
    const { url } = usePage();

    const [sidebarOpen, setSidebarOpen] = useState(false); 
    const [sidebarCollapsed, setSidebarCollapsed] = useState(false); 

    const [isMobile, setIsMobile] = useState(false);
    useEffect(() => {
        const handleResize = () => {
            setIsMobile(window.innerWidth <= 1024);
            if (window.innerWidth > 1024) setSidebarOpen(false);
        };
        handleResize();
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);


    const dashboardLinks = [
        { name: 'لوحة التحكم', icon: <FiGrid />, path: '/dashboard' },
        { name: 'الباقات', icon: <FiGift />, path: '/admin/offers' },
        { name: 'العروض المميزة', icon: <BsStars />, path: '/admin/special-offers' },
        { name: 'الرحلات الأكثر طلبا ', icon: <FiTrendingUp />, path: '/admin/popular-offers' },
        { name: 'المحافظات', icon: <FaMapLocationDot />, path: '/admin/governorates' },
        { name: 'شركات السياحة', icon: <FaRegBuilding />, path: '/admin/tour-companies' },
        { name: 'الفنادق', icon: <MdOutlineHotel />, path: '/admin/hotels' },
        { name: 'أنواع الرحلات ', icon: <MdOutlineCategory />, path: '/admin/trip-types' },
        { name: 'المميزات', icon: <LuPackagePlus />, path: '/admin/features' },
        { name: 'التقييمات', icon: <FiStar />, path: '/admin/testimonials' },
        { name: 'الخدمات', icon: <FaHandsHelping />, path: '/admin/services' },
        { name: 'الإعدادات', icon: <FiSettings />, path: '/users' },
    ];

     const sitePages = [
        { name: 'الصفحة الرئيسية', icon: <FiHome />, path: '/admin/homepage' },
        { name: 'من نحن', icon: <FiBriefcase />, path: '/admin/about-us' },
        { name: 'تواصل معنا', icon: <FiGlobe />, path: '/admin/contact-us' },
        { name: 'رسائل العملاء', icon: <FaRegCommentDots  />, path: '/admin/contact-messages' },
    ];

 
    const renderLinks = (links, expanded) => (
        links.map(link => {
            const isActive = url.includes(link.path);
            return (
                <Link
                    key={link.name}
                    href={link.path}
                    className={`flex items-center gap-3 px-4 py-2 rounded-lg transition
                        ${isActive
                            ? 'bg-[var(--app-primary)] text-white shadow'
                            : 'hover:bg-gray-100 text-gray-700'
                        }`}
                >
                    <span className={`text-lg ${isActive ? 'text-white' : 'text-[var(--app-primary)]'}`}>{link.icon}</span>
                    {expanded && link.name}
                </Link>
            );
        })
    );

    return (
        <div className="max-h-screen flex bg-gray-100 overflow-hidden " dir="rtl">

            {sidebarOpen && isMobile && (
                <div
                    className="fixed inset-0 z-30 bg-black/30"
                    onClick={() => setSidebarOpen(false)}
                />
            )}


            <aside
                className={`fixed lg:relative z-40 bg-[var(--app-bg)] border-r flex-shrink-0 transition-all duration-300
                    ${isMobile
                        ? sidebarOpen ? 'w-64' : 'w-20' 
                        : sidebarCollapsed ? 'w-20' : 'w-64' 
                    } h-screen flex flex-col`}
            >
                <SidebarContent
                    user={user}
                    sidebarOpen={isMobile ? sidebarOpen : !sidebarCollapsed}
                    setSidebarOpen={setSidebarOpen}
                    sidebarCollapsed={sidebarCollapsed}
                    setSidebarCollapsed={setSidebarCollapsed}
                    renderLinks={renderLinks}
                    dashboardLinks={dashboardLinks}
                    sitePages={sitePages}
                    isMobile={isMobile}
                />
            </aside>

            <div className="flex-1 flex flex-col lg:ml-0">
                <Header
                    user={user}
                    sidebarOpen={sidebarOpen}
                    setSidebarOpen={setSidebarOpen}
                    isMobile={isMobile}
                />

                <main className="p-6 flex-1 bg-gray-50 scrollbar-hide h-[calc(100vh-80px)] overflow-y-auto  ">
                     <FlashToast />
                    {children}
                </main>
            </div>
        </div>
    );
}


